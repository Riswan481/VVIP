#!/bin/bash

# Removing the IP check, as it's no longer necessary
clear
echo "Starting Installation..."

# Install required packages
apt update && apt upgrade -y
apt install python3 python3-pip -y
apt install sqlite3 -y

# Set up directories and files
cd /media/
rm -rf cybervpn
wget https://raw.githubusercontent.com/xyzval/VVIP/main/bot/cybervpn.zip
unzip cybervpn.zip
cd cybervpn
rm var.txt
rm database.db

# Install Python dependencies
pip3 install -r requirements.txt
pip install pillow
pip3 install aiohttp
pip3 install paramiko

# Read domain info
nsdom=$(cat /root/nsdomain)
domain=$(cat /etc/xray/domain)
clear
clear
echo
echo "INSTALL BOT CREATE SSH via TELEGRAM"

# Request user input
read -e -p "[*] Input Your Id Telegram: " admin
read -e -p "[*] Input Your bot Telegram: " token
read -e -p "[*] Input username Telegram: " user

# Save the token data
DATADB=$(cat /etc/bot/.bot.db | grep "^#bot#" | grep -w "${token}" | awk '{print $2}')
if [[ "${DATADB}" != '' ]]; then
  sed -i "/\b${token}\b/d" /etc/bot/.bot.db
fi
echo "#bot# ${token} ${admin}" >> /etc/bot/.bot.db

# Set up bot variables
cat > /media/cybervpn/var.txt << END
ADMIN="$admin"
BOT_TOKEN="$token"
DOMAIN="$domain"
DNS="$nsdom"
PUB="7fbd1f8aa0abfe15a7903e837f78aba39cf61d36f183bd604daa2fe4ef3b7b59"
OWN="$user"
SALDO="100000"
END

clear
echo "Done"
echo "Your Data Bot"
echo -e "==============================="
echo "Api Token     : $token"
echo "ID            : $admin"
echo "DOMAIN        : $domain"
echo -e "==============================="
echo "Setting done"

# Remove unnecessary files
rm -f /usr/bin/nenen
echo -e '#!/bin/bash\ncd /media/\npython3 -m cybervpn' > /usr/bin/nenen
chmod 777 /usr/bin/nenen

# Set up systemd service for CyberVPN
cat > /etc/systemd/system/cybervpn.service << END
[Unit]
Description=Simple CyberVPN - @CyberVPN
After=network.target

[Service]
WorkingDirectory=/root
ExecStart=/usr/bin/nenen
Restart=always

[Install]
WantedBy=multi-user.target
END

# Reload and start the service
systemctl daemon-reload
systemctl start cybervpn
systemctl enable cybervpn

# Download panelbot
clear
echo "Downloading asset"
wget -q -O /usr/bin/panelbot "https://raw.githubusercontent.com/xyzval/VVIP/main/bot/panelbot.sh" && chmod +x /usr/bin/panelbot.sh

# Final setup
cp /tmp/var.txt /media/cybervpn
rm -rf bot.sh

clear
echo "Installation complete, type /menu on your bot"
rm /media/cybervpn.zip